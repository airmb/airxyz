-- MySQL dump 10.13  Distrib 5.6.50, for Linux (x86_64)
--
-- Host: localhost    Database: b_aiiu_store
-- ------------------------------------------------------
-- Server version	5.6.50-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `apid`
--

DROP TABLE IF EXISTS `apid`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `apid` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userEmail` char(100) NOT NULL,
  `appleidEmail` char(100) NOT NULL,
  `passwd` char(100) NOT NULL,
  `birthday` char(100) NOT NULL,
  `friendCN` char(100) NOT NULL,
  `parentsCN` char(100) NOT NULL,
  `jobCN` char(100) NOT NULL,
  `addTime` char(100) NOT NULL,
  `lastUpdate` char(100) NOT NULL COMMENT '上一次更新时间',
  `status` char(100) NOT NULL COMMENT '0=不可用，1正常，2等待解锁，3正在解锁，4等待删除设备，4正在删除设备',
  `loopTime` char(100) NOT NULL,
  `msg` char(200) NOT NULL COMMENT '提示信息',
  `shareHtml` char(200) NOT NULL,
  `objHtml` char(100) NOT NULL,
  `token` char(100) NOT NULL,
  `telegramToken` char(100) NOT NULL,
  `telegramChat_id` char(100) NOT NULL,
  `checkNum` char(100) NOT NULL,
  `telegramIsPush` char(100) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apid`
--

LOCK TABLES `apid` WRITE;
/*!40000 ALTER TABLE `apid` DISABLE KEYS */;
/*!40000 ALTER TABLE `apid` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lineList`
--

DROP TABLE IF EXISTS `lineList`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lineList` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(50) NOT NULL COMMENT '线路名',
  `vpsIn_id` char(50) NOT NULL COMMENT '主入口',
  `vpsIn_name` char(50) NOT NULL,
  `vpsIn_ip` char(50) NOT NULL,
  `vpsOut_ids` char(50) NOT NULL COMMENT '主跳板列表',
  `vpsOut_names` char(50) NOT NULL,
  `vpsOut_ip` char(50) NOT NULL,
  `ssl_id` char(50) NOT NULL COMMENT '证书id',
  `sslHost` char(50) NOT NULL,
  `certFile` char(100) NOT NULL,
  `keyFile` char(100) NOT NULL,
  `status` char(10) NOT NULL COMMENT '1正常2生效中3失效',
  `addTime` char(50) NOT NULL,
  `linePasswd` char(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lineList`
--

LOCK TABLES `lineList` WRITE;
/*!40000 ALTER TABLE `lineList` DISABLE KEYS */;
/*!40000 ALTER TABLE `lineList` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portTunnelList`
--

DROP TABLE IF EXISTS `portTunnelList`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `portTunnelList` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lineID` char(10) NOT NULL COMMENT '对应线路id',
  `port` char(10) NOT NULL COMMENT '端口',
  `toIP` char(50) NOT NULL COMMENT '落地id',
  `toPort` char(10) NOT NULL COMMENT '落地端口',
  `name` char(50) NOT NULL COMMENT '备注名字',
  `addTime` char(50) NOT NULL COMMENT '添加时间',
  `status` char(50) NOT NULL COMMENT '1正常2生效中3失效',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portTunnelList`
--

LOCK TABLES `portTunnelList` WRITE;
/*!40000 ALTER TABLE `portTunnelList` DISABLE KEYS */;
/*!40000 ALTER TABLE `portTunnelList` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sslList`
--

DROP TABLE IF EXISTS `sslList`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sslList` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sslHost` char(50) NOT NULL,
  `sslPublicKey` varchar(9000) NOT NULL,
  `sslPrivateKey` varchar(9000) NOT NULL,
  `endTime` char(50) NOT NULL,
  `certFile` char(200) NOT NULL,
  `keyFile` char(200) NOT NULL,
  `addTime` char(50) NOT NULL,
  `certFileLocal` char(100) NOT NULL,
  `keyFileLocal` char(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sslList`
--

LOCK TABLES `sslList` WRITE;
/*!40000 ALTER TABLE `sslList` DISABLE KEYS */;
/*!40000 ALTER TABLE `sslList` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `timerAllList`
--

DROP TABLE IF EXISTS `timerAllList`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `timerAllList` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nameCN` char(50) NOT NULL,
  `nameEN` char(50) NOT NULL,
  `vpsID` char(50) NOT NULL,
  `vpsIP` char(50) NOT NULL,
  `vpsPort` char(50) NOT NULL,
  `vpsPasswd` char(100) NOT NULL,
  `sshAddress` char(200) NOT NULL COMMENT '脚本下载地址',
  `sshName` char(200) NOT NULL COMMENT '脚本名称',
  `p1` char(50) NOT NULL COMMENT '脚本参数',
  `p2` char(100) NOT NULL,
  `p3` char(100) NOT NULL,
  `p4` char(100) NOT NULL,
  `p5` char(100) NOT NULL,
  `lineID` char(50) NOT NULL COMMENT '线路id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=108 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `timerAllList`
--

LOCK TABLES `timerAllList` WRITE;
/*!40000 ALTER TABLE `timerAllList` DISABLE KEYS */;
/*!40000 ALTER TABLE `timerAllList` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` char(50) NOT NULL,
  `passwd` char(50) NOT NULL,
  `isAdmin` char(50) NOT NULL,
  `regTime` char(50) NOT NULL,
  `telegramToken` char(100) NOT NULL,
  `telegramChat_id` char(100) NOT NULL,
  `telegramIsPush` char(100) NOT NULL DEFAULT '0',
  `httpIsPush` char(100) NOT NULL DEFAULT '0',
  `httpStatus` char(10) NOT NULL,
  `httpApi` char(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'admin@airxyz.xyz','96e79218965eb72c92a549dd5a330112','1','2023-06-26 22:33:00','','','0','0','0','');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vps`
--

DROP TABLE IF EXISTS `vps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vps` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ipSSH` char(50) NOT NULL,
  `ipOut` char(50) NOT NULL,
  `port` char(50) NOT NULL,
  `name` char(50) NOT NULL,
  `passwd` char(50) NOT NULL,
  `lastDate` char(50) NOT NULL,
  `cpu` char(50) NOT NULL,
  `cpuUsed` char(50) NOT NULL,
  `mem` char(50) NOT NULL,
  `memUsed` char(50) NOT NULL,
  `disk` char(50) NOT NULL,
  `diskUsed` char(50) NOT NULL,
  `runTime` char(50) NOT NULL,
  `upSpeed` char(50) NOT NULL,
  `downSpeed` char(50) NOT NULL,
  `upTaffic` char(50) NOT NULL,
  `downTaffic` char(50) NOT NULL,
  `apiToken` char(50) NOT NULL,
  `status` char(10) NOT NULL DEFAULT '2',
  `country` char(50) NOT NULL DEFAULT 'other',
  `isInstallAirXyz` char(50) NOT NULL DEFAULT '2' COMMENT '是否安装了监控1安装/其他未安装',
  `isInstallAirXyzPro` char(50) NOT NULL DEFAULT '3' COMMENT '是否安装pro 1安装了2安装中3未安装',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vps`
--

LOCK TABLES `vps` WRITE;
/*!40000 ALTER TABLE `vps` DISABLE KEYS */;
/*!40000 ALTER TABLE `vps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'b_aiiu_store'
--

--
-- Dumping routines for database 'b_aiiu_store'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-07-23 14:44:02
